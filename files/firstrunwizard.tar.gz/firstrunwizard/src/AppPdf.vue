<template>
	<pdf src="https://sagis-am.com/wp-content/uploads/2019/05/SAGIS-Immobilier.pdf" />
</template>
<script>
import pdf from 'vue-pdf'

export default {
	components: {
		pdf
	}
}
</script>
