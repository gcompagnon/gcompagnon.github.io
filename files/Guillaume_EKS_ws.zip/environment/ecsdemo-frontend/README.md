![Build Status](https://codebuild.us-east-2.amazonaws.com/badges?uuid=eyJlbmNyeXB0ZWREYXRhIjoiMnZsWms5clp6NEwvRnJXYUsyWjBmcnBiUWVRaFVsRlpENmg3MWU0M2oxVFpEdDdtSDRVRXJJZm1NNXdGQWIrWVU5UTFHd1RZUTdnU29SV0JyeVNHU1R3PSIsIml2UGFyYW1ldGVyU3BlYyI6InVpTTNLMlRtUEV6ZzJCZ2oiLCJtYXRlcmlhbFNldFNlcmlhbCI6MX0%3D&branch=master)

# Amazon Containers Workshop

This is part of an Amazon Containers workshop at https://ecsworkshop.com or https://eksworkshop.com
